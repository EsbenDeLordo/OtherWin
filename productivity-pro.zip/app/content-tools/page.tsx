"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ContentToolsPage() {
  const [content, setContent] = useState("")
  const [summary, setSummary] = useState("")
  const [activeTab, setActiveTab] = useState("summarize")
  const [maxLength, setMaxLength] = useState("500")

  const handleSummarize = () => {
    // In a real app, this would call an API to summarize the content
    setSummary("Your summary will appear here")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Content Tools</h1>
      <p className="text-muted-foreground">Process and transform your productivity protocols and content</p>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 w-full max-w-md">
          <TabsTrigger value="summarize">Summarize Content</TabsTrigger>
          <TabsTrigger value="extract">Extract Key Points</TabsTrigger>
          <TabsTrigger value="format">Format (Coming Soon)</TabsTrigger>
        </TabsList>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-medium mb-2">Input Content</h2>
              <p className="text-gray-500 mb-4">Paste your productivity protocols or research content to summarize</p>

              <Textarea
                placeholder="Enter content to summarize..."
                className="min-h-[300px] mb-4"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />

              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setContent("")}>
                  Clear
                </Button>
                <Button
                  className="bg-blue-500 hover:bg-blue-600 ml-auto"
                  onClick={handleSummarize}
                  disabled={!content.trim()}
                >
                  Summarize
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-medium mb-2">Summary</h2>
              <p className="text-gray-500 mb-4">AI-generated summary of your content</p>

              <div className="min-h-[300px] mb-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                {summary ? <p>{summary}</p> : <p className="text-gray-400 italic">Your summary will appear here</p>}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500">Max length:</span>
                  <Select value={maxLength} onValueChange={setMaxLength}>
                    <SelectTrigger className="w-[120px]">
                      <SelectValue placeholder="Max length" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="250">250 chars</SelectItem>
                      <SelectItem value="500">500 chars</SelectItem>
                      <SelectItem value="1000">1000 chars</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button variant="outline" disabled={!summary}>
                  <span className="material-icons text-sm mr-1">content_copy</span>
                  Copy
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardContent className="p-6">
            <h2 className="text-xl font-medium mb-4">Usage Tips</h2>
            <ul className="space-y-2 list-disc pl-5">
              <li>Paste productivity protocols or any research content to get a concise summary</li>
              <li>Adjust the maximum length to control the detail level of your summary</li>
              <li>Use the summarized content for quick reference or to share with your team</li>
              <li>For best results, provide structured content with clear sections</li>
            </ul>
          </CardContent>
        </Card>
      </Tabs>
    </div>
  )
}

