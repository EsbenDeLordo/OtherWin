"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

export default function RecommendationsPage() {
  const [filter, setFilter] = useState("active")

  // Sample recommendations
  const recommendations = [
    {
      id: 1,
      title: "Take a strategic break",
      description:
        "Regular breaks improve focus and cognitive function. Try the 50-10 rule: 50 minutes of work followed by a 10-minute break.",
      type: "break",
      icon: "schedule",
    },
    {
      id: 2,
      title: "Schedule strategic breaks",
      description:
        "Taking short breaks every 50-90 minutes can help maintain optimal focus and cognitive function throughout your workday.",
      type: "break",
      icon: "schedule",
    },
    {
      id: 3,
      title: "Morning sunlight exposure",
      description:
        "Getting 10-30 minutes of morning sunlight exposure can help regulate your circadian rhythm and improve focus during the day.",
      type: "focus",
      icon: "wb_sunny",
    },
    {
      id: 4,
      title: "Focus enhancement",
      description:
        "Try the Pomodoro technique: 25-minute focused work sessions with 5-minute breaks. This can significantly improve productivity.",
      type: "focus",
      icon: "psychology",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Recommendations</h1>
        <div className="flex space-x-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="all">All</SelectItem>
            </SelectContent>
          </Select>
          <Button className="bg-blue-500 hover:bg-blue-600">
            <span className="material-icons text-sm mr-1">refresh</span>
            Generate New Recommendations
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {recommendations.map((rec) => (
            <Card key={rec.id}>
              <CardContent className="p-6">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                    <span className="material-icons text-blue-500">{rec.icon}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-medium">{rec.title}</h3>
                      <Badge
                        variant="outline"
                        className={rec.type === "focus" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}
                      >
                        {rec.type === "focus" ? "Focus" : "Break"}
                      </Badge>
                    </div>
                    <p className="text-gray-500 mb-4">{rec.description}</p>
                    <div className="flex space-x-2">
                      {rec.type === "break" ? (
                        <Button className="bg-blue-500 hover:bg-blue-600">Set timer</Button>
                      ) : rec.type === "focus" ? (
                        <Button className="bg-blue-500 hover:bg-blue-600">Set reminder</Button>
                      ) : null}
                      <Button variant="outline">Learn more</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-medium mb-4">About WinDryft Mode</h2>
              <p className="text-gray-500 mb-6">
                Pocket WinDryft Mode provides science-based recommendations to optimize your productivity, focus, and
                well-being throughout your workday, inspired by cutting-edge research on neuroscience and performance.
              </p>

              <h3 className="text-lg font-medium mb-3">Recommendation Types</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                    <span className="material-icons text-purple-500">self_improvement</span>
                  </div>
                  <div>
                    <h4 className="font-medium">NSDR</h4>
                    <p className="text-sm text-gray-500">
                      Non-Sleep Deep Rest sessions to restore focus and consolidate learning.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                    <span className="material-icons text-blue-500">water_drop</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Hydration</h4>
                    <p className="text-sm text-gray-500">
                      Reminders to maintain optimal hydration for cognitive performance.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                    <span className="material-icons text-green-500">directions_run</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Movement</h4>
                    <p className="text-sm text-gray-500">
                      Brief physical activities to boost BDNF and enhance creativity.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                    <span className="material-icons text-blue-500">schedule</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Focus Windows</h4>
                    <p className="text-sm text-gray-500">
                      Optimal timing suggestions for deep work based on your patterns.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
                    <span className="material-icons text-yellow-500">wb_sunny</span>
                  </div>
                  <div>
                    <h4 className="font-medium">Light Exposure</h4>
                    <p className="text-sm text-gray-500">
                      Recommendations for optimizing alertness through light exposure.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="text-lg font-medium mb-2">Productivity Insights</h3>
                <p className="text-gray-600 italic">
                  "Taking a deliberate break every 90 minutes aligns with your body's natural ultradian rhythm and can
                  dramatically improve overall productivity."
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

