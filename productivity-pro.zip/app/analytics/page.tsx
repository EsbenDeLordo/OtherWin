"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("week")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Analytics</h1>
          <p className="text-muted-foreground">Track your productivity patterns and optimize your work habits</p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant={timeRange === "week" ? "default" : "outline"}
            onClick={() => setTimeRange("week")}
            className={timeRange === "week" ? "bg-blue-500 hover:bg-blue-600" : ""}
          >
            Week
          </Button>
          <Button
            variant={timeRange === "month" ? "default" : "outline"}
            onClick={() => setTimeRange("month")}
            className={timeRange === "month" ? "bg-blue-500 hover:bg-blue-600" : ""}
          >
            Month
          </Button>
          <Button
            variant={timeRange === "quarter" ? "default" : "outline"}
            onClick={() => setTimeRange("quarter")}
            className={timeRange === "quarter" ? "bg-blue-500 hover:bg-blue-600" : ""}
          >
            Quarter
          </Button>
        </div>
      </div>

      <div className="border border-dashed rounded-lg p-12 flex flex-col items-center justify-center text-center">
        <span className="material-icons text-4xl text-gray-400 mb-2">analytics</span>
        <h3 className="text-lg font-medium mb-1">No analytics data available</h3>
        <p className="text-gray-500 mb-4">Start working on projects to collect productivity metrics</p>
      </div>
    </div>
  )
}

