"use client"
import { AutomationCenter } from "@/components/automation-center"

export default function AutomationPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Task Automation Center</h1>
      <p className="text-muted-foreground">Create, manage, and run automations to streamline your workflow</p>

      <AutomationCenter />
    </div>
  )
}

