"use client"

import { ChatInterface } from "@/components/chat-interface"

export default function AIAssistantPage() {
  return <ChatInterface />
}

