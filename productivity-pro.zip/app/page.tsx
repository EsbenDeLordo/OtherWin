"use client"

import { useState, useCallback } from "react"
import { useProjects } from "@/context/ProjectContext"
import { ProjectsList } from "@/components/projects-list"
import { DailyChecklist } from "@/components/daily-checklist"
import { PomodoroTimer } from "@/components/pomodoro-timer"
import { WinDryftMode } from "@/components/windryft-mode"
import { Overview } from "@/components/overview"
import { Button } from "@/components/ui/button"
import { ProjectModal } from "@/components/project-modal"
import { Plus } from "lucide-react"

export default function Dashboard() {
  const { selectedProject } = useProjects()
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)

  const handleOpenModal = useCallback(() => {
    setIsCreateModalOpen(true)
  }, [])

  const handleCloseModal = useCallback(() => {
    setIsCreateModalOpen(false)
  }, [])

  // If a project is selected, show the projects list with the selected project
  if (selectedProject) {
    return <ProjectsList />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back. Here's your productivity overview.</p>
        </div>
        <Button className="bg-blue-500 hover:bg-blue-600" onClick={handleOpenModal}>
          <Plus className="h-4 w-4 mr-1" />
          New Project
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Overview />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <PomodoroTimer />
          <div className="bg-white dark:bg-gray-800 rounded-lg border">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-medium">Current Projects</h2>
              <a href="/projects" className="text-blue-500 text-sm">
                View all
              </a>
            </div>
            <div className="p-4">
              <ProjectsList embedded={true} limit={4} />
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <DailyChecklist />
          <WinDryftMode />
        </div>
      </div>

      {isCreateModalOpen && <ProjectModal isOpen={isCreateModalOpen} onClose={handleCloseModal} />}
    </div>
  )
}

