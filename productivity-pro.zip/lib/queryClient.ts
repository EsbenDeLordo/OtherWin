"use client"

import { QueryClient } from "@tanstack/react-query"

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000,
      refetchOnWindowFocus: false,
    },
  },
})

export async function apiRequest(method: string, endpoint: string, data?: any) {
  // In a real app, this would make actual API requests
  // For demo purposes, we'll simulate responses

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Mock API responses
  if (endpoint.includes("/api/assistant-messages")) {
    if (method === "GET") {
      return {
        json: () =>
          Promise.resolve([
            {
              id: 1,
              sender: "user",
              content: "How can I improve my productivity?",
              timestamp: new Date().toISOString(),
            },
            {
              id: 2,
              sender: "assistant",
              content: "I recommend using the Pomodoro technique and time blocking to structure your day.",
              timestamp: new Date().toISOString(),
            },
          ]),
      }
    }

    if (method === "POST") {
      return {
        json: () => Promise.resolve({ id: Date.now(), ...data, timestamp: new Date().toISOString() }),
      }
    }
  }

  if (endpoint.includes("/api/analytics")) {
    return {
      json: () =>
        Promise.resolve([
          {
            date: new Date().toISOString(),
            focusTime: 240,
            flowStates: 3,
            productivity: 85,
          },
        ]),
    }
  }

  if (endpoint.includes("/api/summarize")) {
    return {
      json: () =>
        Promise.resolve({
          summary:
            "This is an AI-generated summary of the content you provided. It highlights the key points and main ideas in a concise format, making it easier to understand and reference later.",
        }),
    }
  }

  // Default response
  return {
    json: () => Promise.resolve({ success: true }),
  }
}

