/**
 * Enhanced storage utility for persisting data with type safety
 * This version uses a simple Base64 encoding for "encryption" (not secure for production)
 */

const storage = {
  /**
   * Get data from localStorage with type safety
   * @param key Storage key
   * @param defaultValue Default value if key doesn't exist
   * @param isEncoded Whether the data is encoded
   * @returns Retrieved value or default value
   */
  get: <T,>(key: string, defaultValue: T, isEncoded = false): T => {
    if (typeof window === "undefined") return defaultValue

    try {
      const item = localStorage.getItem(key)
      if (!item) return defaultValue

      if (isEncoded) {
        // Decode the data (simple base64 decoding)
        const decoded = atob(item)
        return JSON.parse(decoded)
      }

      return JSON.parse(item)
    } catch (error) {
      console.error(`Error getting item ${key} from localStorage:`, error)
      return defaultValue
    }
  },

  /**
   * Set data in localStorage with type safety
   * @param key Storage key
   * @param value Value to store
   * @param isEncoded Whether to encode the data
   */
  set: <T,>(key: string, value: T, isEncoded = false): void => {
    if (typeof window === "undefined") return

    try {
      if (isEncoded) {
        // Encode the data (simple base64 encoding)
        const encoded = btoa(JSON.stringify(value))
        localStorage.setItem(key, encoded)
      } else {
        localStorage.setItem(key, JSON.stringify(value))
      }
    } catch (error) {
      console.error(`Error setting item ${key} in localStorage:`, error)
    }
  },

  /**
   * Remove data from localStorage
   * @param key Storage key
   */
  remove: (key: string): void => {
    if (typeof window === "undefined") return

    try {
      localStorage.removeItem(key)
    } catch (error) {
      console.error(`Error removing item ${key} from localStorage:`, error)
    }
  },

  /**
   * Clear all data from localStorage
   */
  clear: (): void => {
    if (typeof window === "undefined") return

    try {
      localStorage.clear()
    } catch (error) {
      console.error("Error clearing localStorage:", error)
    }
  },

  /**
   * Check if a key exists in localStorage
   * @param key Storage key
   * @returns Whether the key exists
   */
  exists: (key: string): boolean => {
    if (typeof window === "undefined") return false

    return localStorage.getItem(key) !== null
  },
}

export default storage

