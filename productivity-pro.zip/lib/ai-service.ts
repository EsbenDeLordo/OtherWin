import storage from "./storage-simple"
import { v4 as uuidv4 } from "uuid"

export type AIProvider = "auto" | "deepseek" | "gemini"

export interface AIConfig {
  provider: AIProvider
  deepseekApiKey?: string
  geminiApiKey?: string
}

export interface AIMessage {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: string
  provider?: string
}

export interface AIConversation {
  id: string
  name: string
  projectId: number | null
  messages: AIMessage[]
  lastUpdated: string
}

// Default API keys (using the provided keys)
export const DEFAULT_AI_CONFIG: AIConfig = {
  provider: "auto", // Default to auto, which will prefer Gemini
  deepseekApiKey: "sk-059b15933e554d2b8719f9b81316c0f1",
  geminiApiKey: "AIzaSyA8pVCXhk7uVDgUNcrUqOmUwCK1dECWyPg",
}

// Storage keys
const AI_CONFIG_KEY = "productivity_pro_ai_config"
const AI_CONVERSATIONS_KEY = "productivity_pro_conversations"

// Get the current AI configuration
export const getAIConfig = (): AIConfig => {
  return storage.get<AIConfig>(AI_CONFIG_KEY, DEFAULT_AI_CONFIG, true)
}

// Save AI configuration
export const saveAIConfig = (config: AIConfig): void => {
  storage.set<AIConfig>(AI_CONFIG_KEY, config, true)
}

// Check if AI is configured
export const isAIConfigured = (): boolean => {
  const config = getAIConfig()
  if (config.provider === "auto") {
    return !!config.deepseekApiKey || !!config.geminiApiKey
  } else if (config.provider === "deepseek") {
    return !!config.deepseekApiKey
  } else if (config.provider === "gemini") {
    return !!config.geminiApiKey
  }
  return false
}

// Get the active provider based on configuration
export const getActiveProvider = (): string => {
  const config = getAIConfig()
  if (config.provider === "auto") {
    // Prefer Gemini as requested
    if (config.geminiApiKey) return "gemini"
    if (config.deepseekApiKey) return "deepseek"
    return "demo"
  }
  return config.provider
}

// Get all conversations
export const getConversations = (): AIConversation[] => {
  return storage.get<AIConversation[]>(AI_CONVERSATIONS_KEY, [])
}

// Get a specific conversation
export const getConversation = (id: string): AIConversation | null => {
  const conversations = getConversations()
  return conversations.find((conv) => conv.id === id) || null
}

// Get conversations for a project
export const getProjectConversations = (projectId: number | null): AIConversation[] => {
  const conversations = getConversations()
  return conversations.filter((conv) => conv.projectId === projectId)
}

// Create a new conversation
export const createConversation = (name: string, projectId: number | null): AIConversation => {
  const conversations = getConversations()
  const newConversation: AIConversation = {
    id: uuidv4(),
    name,
    projectId,
    messages: [],
    lastUpdated: new Date().toISOString(),
  }

  conversations.push(newConversation)
  storage.set<AIConversation[]>(AI_CONVERSATIONS_KEY, conversations)
  return newConversation
}

// Add a message to a conversation
export const addMessageToConversation = (
  conversationId: string,
  message: Omit<AIMessage, "id" | "timestamp">,
): AIConversation | null => {
  const conversations = getConversations()
  const conversationIndex = conversations.findIndex((conv) => conv.id === conversationId)

  if (conversationIndex === -1) return null

  const newMessage: AIMessage = {
    ...message,
    id: uuidv4(),
    timestamp: new Date().toISOString(),
  }

  conversations[conversationIndex].messages.push(newMessage)
  conversations[conversationIndex].lastUpdated = new Date().toISOString()

  storage.set<AIConversation[]>(AI_CONVERSATIONS_KEY, conversations)
  return conversations[conversationIndex]
}

// Delete a conversation
export const deleteConversation = (id: string): boolean => {
  const conversations = getConversations()
  const filteredConversations = conversations.filter((conv) => conv.id !== id)

  if (filteredConversations.length === conversations.length) {
    return false // Conversation not found
  }

  storage.set<AIConversation[]>(AI_CONVERSATIONS_KEY, filteredConversations)
  return true
}

// Clear all conversations
export const clearConversations = (): void => {
  storage.set<AIConversation[]>(AI_CONVERSATIONS_KEY, [])
}

// Test API key validity
export const testApiKey = async (provider: "gemini" | "deepseek", apiKey: string): Promise<boolean> => {
  try {
    if (provider === "gemini") {
      // Test Gemini API key with a simple request
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [{ parts: [{ text: "Hello, this is a test message." }] }],
          }),
        },
      )

      const data = await response.json()
      return !data.error
    } else {
      // Test DeepSeek API key with a simple request
      const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "deepseek-chat",
          messages: [{ role: "user", content: "Hello, this is a test message." }],
        }),
      })

      const data = await response.json()
      return !data.error
    }
  } catch (error) {
    console.error(`Error testing ${provider} API key:`, error)
    return false
  }
}

// Send a message to the AI
export const sendMessageToAI = async (
  message: string,
  conversationId?: string,
  projectId?: number | null,
): Promise<{ content: string; provider: string; conversationId: string }> => {
  const config = getAIConfig()
  const provider = getActiveProvider()

  // Create or get conversation
  let conversation: AIConversation | null = null

  if (conversationId) {
    conversation = getConversation(conversationId)
  }

  if (!conversation) {
    conversation = createConversation(`Conversation ${new Date().toLocaleString()}`, projectId || null)
  }

  // Add user message to conversation
  addMessageToConversation(conversation.id, {
    role: "user",
    content: message,
  })

  try {
    let aiResponse = ""

    if (provider === "demo") {
      aiResponse = "I'm currently in demo mode. To use AI features, please configure your API keys in the settings."
    } else if (provider === "gemini" && config.geminiApiKey) {
      // Make actual API call to Gemini - Fixed API endpoint and request format
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${config.geminiApiKey}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              contents: [
                {
                  parts: [{ text: message }],
                },
              ],
              generationConfig: {
                temperature: 0.7,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: 1024,
              },
            }),
          },
        )

        const data = await response.json()

        if (data.error) {
          throw new Error(data.error.message || "Error calling Gemini API")
        }

        // Extract the response text from the correct path in the response
        if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) {
          aiResponse = data.candidates[0].content.parts[0].text || "No response generated."
        } else {
          throw new Error("Unexpected response format from Gemini API")
        }
      } catch (error) {
        console.error("Error calling Gemini API:", error)
        aiResponse = `There was an error processing your request with Gemini: ${error.message}. Please try again later.`
      }
    } else if (provider === "deepseek" && config.deepseekApiKey) {
      // Make actual API call to DeepSeek
      try {
        const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.deepseekApiKey}`,
          },
          body: JSON.stringify({
            model: "deepseek-chat",
            messages: [{ role: "user", content: message }],
            temperature: 0.7,
            max_tokens: 1024,
          }),
        })

        const data = await response.json()

        if (data.error) {
          throw new Error(data.error.message || "Error calling DeepSeek API")
        }

        aiResponse = data.choices[0].message.content
      } catch (error) {
        console.error("Error calling DeepSeek API:", error)
        aiResponse = `There was an error processing your request with DeepSeek: ${error.message}. Please try again later.`
      }
    } else {
      aiResponse = "No valid AI provider configured. Please check your settings and API keys."
    }

    // Add AI response to conversation
    addMessageToConversation(conversation.id, {
      role: "assistant",
      content: aiResponse,
      provider,
    })

    return {
      content: aiResponse,
      provider,
      conversationId: conversation.id,
    }
  } catch (error) {
    console.error("Error calling AI API:", error)
    const errorMessage = `There was an error processing your request: ${error.message}. Please try again later.`

    // Add error message to conversation
    addMessageToConversation(conversation.id, {
      role: "assistant",
      content: errorMessage,
      provider: "error",
    })

    return {
      content: errorMessage,
      provider: "error",
      conversationId: conversation.id,
    }
  }
}

// Analyze content with AI
export const analyzeContentWithAI = async (
  content: string,
  conversationId?: string,
  projectId?: number | null,
): Promise<{ content: string; provider: string; conversationId: string }> => {
  const message = `Please analyze the following content: ${content}`
  return sendMessageToAI(message, conversationId, projectId)
}

// Generate task suggestions with AI
export const generateTaskSuggestions = async (
  projectDescription: string,
  conversationId?: string,
  projectId?: number | null,
): Promise<{ content: string; provider: string; conversationId: string }> => {
  const message = `Based on this project description: "${projectDescription}", please suggest a list of tasks that would help complete this project. Format the response as a bulleted list.`
  return sendMessageToAI(message, conversationId, projectId)
}

// Summarize project with AI
export const summarizeProject = async (
  projectDetails: any,
  conversationId?: string,
  projectId?: number | null,
): Promise<{ content: string; provider: string; conversationId: string }> => {
  const message = `Please provide a summary of this project: ${JSON.stringify(projectDetails)}. Include key metrics, progress, and next steps.`
  return sendMessageToAI(message, conversationId, projectId)
}

