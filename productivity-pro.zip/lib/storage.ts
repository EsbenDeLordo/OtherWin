/**
 * Enhanced storage utility for persisting data with type safety and encryption for sensitive data
 */

// Instead of importing specific modules, import the entire library
import CryptoJS from "crypto-js"

// Encryption key for sensitive data (in a real app, this would be more securely managed)
const ENCRYPTION_KEY = "productivity-pro-secure-key-2024"

const storage = {
  /**
   * Get data from localStorage with type safety
   * @param key Storage key
   * @param defaultValue Default value if key doesn't exist
   * @param isEncrypted Whether the data is encrypted
   * @returns Retrieved value or default value
   */
  get: <T,>(key: string, defaultValue: T, isEncrypted = false): T => {
    if (typeof window === "undefined") return defaultValue

    try {
      const item = localStorage.getItem(key)
      if (!item) return defaultValue

      if (isEncrypted) {
        // Decrypt the data
        const decrypted = CryptoJS.AES.decrypt(item, ENCRYPTION_KEY).toString(CryptoJS.enc.Utf8)
        return decrypted ? JSON.parse(decrypted) : defaultValue
      }

      return JSON.parse(item)
    } catch (error) {
      console.error(`Error getting item ${key} from localStorage:`, error)
      return defaultValue
    }
  },

  /**
   * Set data in localStorage with type safety
   * @param key Storage key
   * @param value Value to store
   * @param isEncrypted Whether to encrypt the data
   */
  set: <T,>(key: string, value: T, isEncrypted = false): void => {
    if (typeof window === "undefined") return

    try {
      if (isEncrypted) {
        // Encrypt the data
        const encrypted = CryptoJS.AES.encrypt(JSON.stringify(value), ENCRYPTION_KEY).toString()
        localStorage.setItem(key, encrypted)
      } else {
        localStorage.setItem(key, JSON.stringify(value))
      }
    } catch (error) {
      console.error(`Error setting item ${key} in localStorage:`, error)
    }
  },

  /**
   * Remove data from localStorage
   * @param key Storage key
   */
  remove: (key: string): void => {
    if (typeof window === "undefined") return

    try {
      localStorage.removeItem(key)
    } catch (error) {
      console.error(`Error removing item ${key} from localStorage:`, error)
    }
  },

  /**
   * Clear all data from localStorage
   */
  clear: (): void => {
    if (typeof window === "undefined") return

    try {
      localStorage.clear()
    } catch (error) {
      console.error("Error clearing localStorage:", error)
    }
  },

  /**
   * Check if a key exists in localStorage
   * @param key Storage key
   * @returns Whether the key exists
   */
  exists: (key: string): boolean => {
    if (typeof window === "undefined") return false

    return localStorage.getItem(key) !== null
  },
}

export default storage

