import { z } from "zod"

export interface WorkSession {
  id: string
  projectId: number | null
  type: "focus" | "meeting" | "learning"
  startTime: string
  endTime?: string
}

export interface DailyAnalytics {
  date: string
  focusTime: number
  flowStates: number
  productivity: number
}

export interface AssistantMessage {
  id: number
  userId: number
  projectId?: number | null
  content: string
  sender: "user" | "assistant"
  provider?: string
  timestamp: string
}

export interface Project {
  id: number
  name: string
  description: string
  type: string
  progress: number
  deadline?: string
  timeLogged: number
  files: number
  colorCode: string
  icon: string
  userId: number
  aiAssistanceEnabled?: boolean
}

export interface ProjectTemplate {
  id: number
  type: string
  name: string
  description: string
  sections: any[]
}

export interface Recommendation {
  id: number
  title: string
  description: string
  type: string
  icon: string
  actionText: string
  secondaryActionText?: string
  isCompleted: boolean
}

export interface User {
  id: number
  name: string
  email: string
  avatar?: string
}

export const insertProjectSchema = z.object({
  name: z.string(),
  description: z.string().optional(),
  type: z.string(),
  userId: z.number(),
  deadline: z.string().optional(),
  aiAssistanceEnabled: z.boolean().default(true),
  colorCode: z.string(),
  icon: z.string(),
})

