"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Trash2, MessageSquare, MoreVertical, History, Plus, KeyRound, Loader2, AlertTriangle } from "lucide-react"
import { useProjects } from "@/context/ProjectContext"
import { AISettingsDialog } from "@/components/ai-settings-dialog"
import {
  sendMessageToAI,
  getActiveProvider,
  isAIConfigured,
  getConversations,
  getProjectConversations,
  deleteConversation,
  type AIConversation,
  generateTaskSuggestions,
} from "@/lib/ai-service"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface ChatInterfaceProps {
  projectId?: number | null
  embedded?: boolean
  onGenerateTasks?: (tasks: string) => void
}

export function ChatInterface({ projectId = null, embedded = false, onGenerateTasks }: ChatInterfaceProps) {
  const { toast } = useToast()
  const { projects } = useProjects()
  const [message, setMessage] = useState("")
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(projectId)
  const [contentToAnalyze, setContentToAnalyze] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [showConversationHistory, setShowConversationHistory] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isApiKeyDialogOpen, setIsApiKeyDialogOpen] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [conversations, setConversations] = useState<AIConversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<AIConversation | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isGeneratingTasks, setIsGeneratingTasks] = useState(false)

  // Load conversations
  useEffect(() => {
    if (projectId !== null) {
      const projectConversations = getProjectConversations(projectId)
      setConversations(projectConversations)

      // Select the most recent conversation if available
      if (projectConversations.length > 0) {
        const sortedConversations = [...projectConversations].sort(
          (a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime(),
        )
        setSelectedConversation(sortedConversations[0])
      }
    } else {
      const allConversations = getConversations()
      setConversations(allConversations)

      // Select the most recent general conversation if available
      const generalConversations = allConversations.filter((c) => c.projectId === null)
      if (generalConversations.length > 0) {
        const sortedConversations = [...generalConversations].sort(
          (a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime(),
        )
        setSelectedConversation(sortedConversations[0])
      }
    }
  }, [projectId])

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [selectedConversation])

  // Handle message sending
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!message.trim()) return
    setIsProcessing(true)
    setError(null)

    try {
      const response = await sendMessageToAI(message, selectedConversation?.id, selectedProjectId)

      // Update conversations list
      const updatedConversations = getConversations()
      setConversations(updatedConversations)

      // Update selected conversation
      const updatedConversation = updatedConversations.find((c) => c.id === response.conversationId)
      if (updatedConversation) {
        setSelectedConversation(updatedConversation)
      }

      // Clear input
      setMessage("")
    } catch (error) {
      console.error("Error sending message:", error)
      setError("Failed to send message. Please try again.")
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  // Handle content analysis
  const handleAnalyzeContent = async () => {
    if (!contentToAnalyze.trim()) {
      toast({
        title: "Empty content",
        description: "Please enter some content to analyze.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)
    setError(null)

    try {
      const response = await sendMessageToAI(
        `Please analyze the following content: ${contentToAnalyze}`,
        selectedConversation?.id,
        selectedProjectId,
      )

      // Update conversations list
      const updatedConversations = getConversations()
      setConversations(updatedConversations)

      // Update selected conversation
      const updatedConversation = updatedConversations.find((c) => c.id === response.conversationId)
      if (updatedConversation) {
        setSelectedConversation(updatedConversation)
      }

      // Clear input
      setContentToAnalyze("")

      toast({
        title: "Content analyzed",
        description: "AI has analyzed your content.",
      })
    } catch (error) {
      console.error("Error analyzing content:", error)
      setError("Failed to analyze content. Please try again.")
      toast({
        title: "Error",
        description: "Failed to analyze content. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  // Generate task suggestions
  const handleGenerateTasks = async () => {
    if (!projectId) return

    const project = projects.find((p) => p.id === projectId)
    if (!project) return

    setIsGeneratingTasks(true)
    setError(null)

    try {
      const response = await generateTaskSuggestions(project.description, selectedConversation?.id, projectId)

      // Update conversations list
      const updatedConversations = getConversations()
      setConversations(updatedConversations)

      // Update selected conversation
      const updatedConversation = updatedConversations.find((c) => c.id === response.conversationId)
      if (updatedConversation) {
        setSelectedConversation(updatedConversation)
      }

      // Pass tasks to parent component if callback exists
      if (onGenerateTasks) {
        onGenerateTasks(response.content)
      }

      toast({
        title: "Tasks Generated",
        description: "AI has generated task suggestions for your project.",
      })
    } catch (error) {
      console.error("Error generating tasks:", error)
      setError("Failed to generate tasks. Please try again.")
      toast({
        title: "Error",
        description: "Failed to generate tasks. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingTasks(false)
    }
  }

  // Create a new conversation
  const handleNewChat = () => {
    sendMessageToAI("Hello, I'd like to start a new conversation.", undefined, selectedProjectId).then((response) => {
      // Update conversations list
      const updatedConversations = getConversations()
      setConversations(updatedConversations)

      // Update selected conversation
      const newConversation = updatedConversations.find((c) => c.id === response.conversationId)
      if (newConversation) {
        setSelectedConversation(newConversation)
      }

      setShowConversationHistory(false)

      toast({
        title: "New conversation started",
        description: "You're now in a fresh conversation with your AI assistant.",
      })
    })
  }

  // Switch to a different conversation
  const handleSwitchConversation = (conversation: AIConversation) => {
    setSelectedConversation(conversation)
    setShowConversationHistory(false)
  }

  // Delete conversation
  const handleDeleteConversation = () => {
    if (!selectedConversation) return

    const success = deleteConversation(selectedConversation.id)

    if (success) {
      // Update conversations list
      const updatedConversations = getConversations()
      setConversations(updatedConversations)

      // Select a new conversation if available
      if (updatedConversations.length > 0) {
        const projectConvs =
          projectId !== null
            ? updatedConversations.filter((c) => c.projectId === projectId)
            : updatedConversations.filter((c) => c.projectId === null)

        if (projectConvs.length > 0) {
          setSelectedConversation(projectConvs[0])
        } else {
          setSelectedConversation(null)
        }
      } else {
        setSelectedConversation(null)
      }

      toast({
        title: "Conversation deleted",
        description: "The conversation has been removed.",
      })
    } else {
      toast({
        title: "Error",
        description: "Failed to delete conversation. Please try again.",
        variant: "destructive",
      })
    }

    setIsDeleteDialogOpen(false)
  }

  // Format date for display
  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr)
    const now = new Date()
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffInDays === 0) {
      return `Today at ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    } else if (diffInDays === 1) {
      return "Yesterday"
    } else if (diffInDays < 7) {
      const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
      return days[date.getDay()]
    } else {
      return date.toLocaleDateString()
    }
  }

  // Add API key
  const handleAddApiKey = () => {
    setIsApiKeyDialogOpen(true)
  }

  // Get the active provider
  const activeProvider = getActiveProvider()
  const aiConfigured = isAIConfigured()

  return (
    <div className={embedded ? "" : "grid grid-cols-1 lg:grid-cols-3 gap-6"}>
      <div className={embedded ? "" : "lg:col-span-2"}>
        <Card className="h-full flex flex-col">
          <CardHeader className="flex flex-row items-center justify-between py-3">
            <div className="flex items-center">
              <CardTitle>AI Assistant</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="ml-2"
                onClick={() => setShowConversationHistory(!showConversationHistory)}
              >
                <History className="h-4 w-4 mr-1" />
                <span className="text-xs">History</span>
              </Button>
            </div>
            <div className="flex items-center space-x-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Options</DropdownMenuLabel>
                  <DropdownMenuItem onClick={handleNewChat}>
                    <Plus className="mr-2 h-4 w-4" />
                    New Chat
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleAddApiKey}>
                    <KeyRound className="mr-2 h-4 w-4" />
                    AI Settings
                    <span className="ml-2 text-xs text-gray-500">
                      ({activeProvider === "demo" ? "Not Configured" : activeProvider})
                    </span>
                  </DropdownMenuItem>
                  {embedded && projectId && (
                    <DropdownMenuItem onClick={handleGenerateTasks} disabled={isGeneratingTasks}>
                      <Plus className="mr-2 h-4 w-4" />
                      Generate Task Suggestions
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => setIsDeleteDialogOpen(true)}
                    className="text-destructive focus:text-destructive"
                    disabled={!selectedConversation}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete Conversation
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {!embedded && (
                <Select
                  value={selectedProjectId?.toString() || "general"}
                  onValueChange={(value) => setSelectedProjectId(value === "general" ? null : Number(value))}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="General" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id.toString()}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </CardHeader>

          {/* AI Settings Dialog */}
          <AISettingsDialog open={isApiKeyDialogOpen} onOpenChange={setIsApiKeyDialogOpen} />

          <CardContent className="flex-1 overflow-hidden flex flex-col pb-4 relative">
            {showConversationHistory && (
              <div className="absolute inset-0 bg-white dark:bg-gray-800 z-10 p-4 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">Conversation History</h3>
                  <Button variant="ghost" size="sm" onClick={() => setShowConversationHistory(false)}>
                    <span className="material-icons">close</span>
                  </Button>
                </div>

                <ScrollArea className="flex-1">
                  {conversations.length > 0 ? (
                    <div className="space-y-2">
                      {conversations
                        .filter((c) => (projectId === null ? true : c.projectId === projectId))
                        .sort((a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime())
                        .map((conversation) => (
                          <div
                            key={conversation.id}
                            className={`p-3 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 ${
                              selectedConversation?.id === conversation.id ? "bg-gray-100 dark:bg-gray-700" : ""
                            }`}
                            onClick={() => handleSwitchConversation(conversation)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <MessageSquare className="h-4 w-4 mr-2 text-gray-500" />
                                <span className="font-medium text-sm">{conversation.name}</span>
                              </div>
                              <span className="text-xs text-gray-500">{formatDate(conversation.lastUpdated)}</span>
                            </div>
                            {conversation.messages.length > 0 && (
                              <p className="text-xs text-gray-500 mt-1 truncate">
                                {conversation.messages[conversation.messages.length - 1].content}
                              </p>
                            )}
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <p>No conversation history yet</p>
                    </div>
                  )}
                </ScrollArea>

                <div className="mt-4">
                  <Button onClick={handleNewChat} className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    New Conversation
                  </Button>
                </div>
              </div>
            )}

            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <ScrollArea className="h-[400px] mb-4">
              <div className="space-y-4 pr-2">
                {selectedConversation && selectedConversation.messages.length > 0 ? (
                  selectedConversation.messages.map((msg, index) => (
                    <div key={index} className={`flex items-start ${msg.role === "user" ? "justify-end" : ""}`}>
                      {msg.role === "assistant" && (
                        <div className="flex-shrink-0 bg-gray-100 dark:bg-gray-700 rounded-full p-2">
                          <span className="material-icons text-sm text-gray-500 dark:text-gray-400">smart_toy</span>
                        </div>
                      )}

                      <div
                        className={`mx-3 max-w-xs md:max-w-md rounded-lg p-3 ${
                          msg.role === "user" ? "bg-primary text-white" : "bg-gray-100 dark:bg-gray-700"
                        }`}
                      >
                        {msg.role === "assistant" && msg.provider && (
                          <div className="flex items-center mb-1">
                            <span
                              className={`text-xs px-1.5 py-0.5 rounded ${
                                msg.provider === "deepseek"
                                  ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                                  : msg.provider === "gemini"
                                    ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300"
                                    : "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300"
                              }`}
                            >
                              {msg.provider === "deepseek" ? "DeepSeek" : msg.provider === "gemini" ? "Gemini" : "AI"}
                            </span>
                          </div>
                        )}
                        <p
                          className={`text-sm ${
                            msg.role === "user" ? "text-white" : "text-gray-800 dark:text-gray-200"
                          }`}
                        >
                          {msg.content ===
                          "I'm currently in demo mode. To use AI features, please configure your API keys in the settings." ? (
                            <span>
                              I'm currently in demo mode and can't provide detailed responses.
                              <Button
                                variant="link"
                                className="p-0 h-auto text-xs text-blue-400 dark:text-blue-300"
                                onClick={handleAddApiKey}
                              >
                                Add an API key to enhance capabilities.
                              </Button>
                            </span>
                          ) : (
                            msg.content
                          )}
                        </p>
                      </div>

                      {msg.role === "user" && (
                        <div className="flex-shrink-0 bg-gray-100 dark:bg-gray-700 rounded-full p-2">
                          <span className="material-icons text-sm text-gray-500 dark:text-gray-400">person</span>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="flex flex-col items-center justify-center h-64 text-center">
                    <span className="material-icons text-5xl text-gray-400 mb-4">smart_toy</span>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">Your AI Assistant</h3>
                    <p className="text-gray-500 dark:text-gray-400 max-w-sm mt-2">
                      Ask for help with your projects, get recommendations, or analyze content.
                    </p>
                    {!aiConfigured && (
                      <Button variant="outline" className="mt-4" onClick={handleAddApiKey}>
                        <KeyRound className="mr-2 h-4 w-4" />
                        Configure AI
                      </Button>
                    )}
                  </div>
                )}

                {isProcessing && (
                  <div className="flex items-start">
                    <div className="flex-shrink-0 bg-gray-100 dark:bg-gray-700 rounded-full p-2">
                      <span className="material-icons text-sm text-gray-500 dark:text-gray-400">smart_toy</span>
                    </div>
                    <div className="ml-3 max-w-xs md:max-w-md bg-gray-100 dark:bg-gray-700 rounded-lg p-3">
                      <div className="flex flex-col">
                        <div className="flex items-center mb-1">
                          <span
                            className={`text-xs px-1.5 py-0.5 rounded ${
                              activeProvider === "deepseek"
                                ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                                : activeProvider === "gemini"
                                  ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300"
                                  : "bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300"
                            }`}
                          >
                            {activeProvider === "deepseek" ? "DeepSeek" : activeProvider === "gemini" ? "Gemini" : "AI"}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Loader2 className="h-4 w-4 animate-spin text-gray-500" />
                          <span className="text-sm text-gray-500 dark:text-gray-400">Thinking...</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <form className="flex" onSubmit={handleSendMessage}>
              <Input
                type="text"
                placeholder="Ask your AI assistant..."
                className="flex-1"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                disabled={isProcessing}
              />
              <Button type="submit" className="ml-3" disabled={isProcessing || !message.trim()}>
                <span className="material-icons text-sm">send</span>
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {!embedded && (
        <div>
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Content Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Paste content below to get AI analysis and suggestions
                  </p>
                  <Textarea
                    placeholder="Paste your content here..."
                    className="min-h-[200px]"
                    value={contentToAnalyze}
                    onChange={(e) => setContentToAnalyze(e.target.value)}
                    disabled={isProcessing}
                  />
                  <Button
                    onClick={handleAnalyzeContent}
                    disabled={isProcessing || !contentToAnalyze.trim() || !aiConfigured}
                    className="w-full"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <span className="material-icons mr-2 text-sm">psychology</span>
                        Analyze Content
                      </>
                    )}
                  </Button>

                  {!aiConfigured && (
                    <p className="text-xs text-amber-600 dark:text-amber-400 text-center mt-2">
                      Configure AI settings to enable content analysis
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Prompts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      if (aiConfigured) {
                        setMessage("Help me organize my project structure")
                        handleSendMessage(new Event("submit") as any)
                      } else {
                        handleAddApiKey()
                      }
                    }}
                    disabled={isProcessing}
                  >
                    <span className="material-icons mr-2 text-sm">folder</span>
                    Help with project organization
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      if (aiConfigured) {
                        setMessage("I need ideas for my current project")
                        handleSendMessage(new Event("submit") as any)
                      } else {
                        handleAddApiKey()
                      }
                    }}
                    disabled={isProcessing}
                  >
                    <span className="material-icons mr-2 text-sm">lightbulb</span>
                    Generate ideas
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      if (aiConfigured) {
                        setMessage("Summarize research on cognitive enhancement techniques")
                        handleSendMessage(new Event("submit") as any)
                      } else {
                        handleAddApiKey()
                      }
                    }}
                    disabled={isProcessing}
                  >
                    <span className="material-icons mr-2 text-sm">summarize</span>
                    Research summary
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => {
                      if (aiConfigured) {
                        setMessage("Write an outline for my project")
                        handleSendMessage(new Event("submit") as any)
                      } else {
                        handleAddApiKey()
                      }
                    }}
                    disabled={isProcessing}
                  >
                    <span className="material-icons mr-2 text-sm">format_list_bulleted</span>
                    Create outline
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}

