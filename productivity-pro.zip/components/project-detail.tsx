"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useMutation } from "@tanstack/react-query"
import { useWorkSession } from "@/context/WorkSessionContext"
import { useToast } from "@/hooks/use-toast"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Timer } from "@/components/ui/timer"
import { Textarea } from "@/components/ui/textarea"
import { ChatInterface } from "@/components/chat-interface"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import {
  AlertTriangle,
  Calendar,
  Clock,
  Edit,
  FileText,
  Loader2,
  Play,
  Plus,
  Save,
  Share,
  Square,
  Trash2,
  Upload,
} from "lucide-react"
import storage from "@/lib/storage"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface Project {
  id: number
  name: string
  description: string
  type: string
  progress: number
  deadline?: string
  timeLogged: number
  files: number
  colorCode: string
  icon: string
  userId: number
  aiAssistanceEnabled?: boolean
}

interface Task {
  id: string
  text: string
  completed: boolean
  projectId: number
  createdAt: string
  updatedAt: string
}

interface ProjectDetailProps {
  project: Project
  onUpdate: (project: Project) => void
  onClose: () => void
  onDelete?: (projectId: number) => void
}

interface ProjectNote {
  id: string
  content: string
  projectId: number
  createdAt: string
  updatedAt: string
}

interface ProjectFile {
  id: string
  name: string
  type: string
  size: number
  url: string
  projectId: number
  createdAt: string
}

const TASKS_STORAGE_KEY = "productivity_pro_tasks"
const NOTES_STORAGE_KEY = "productivity_pro_notes"
const FILES_STORAGE_KEY = "productivity_pro_files"

export function ProjectDetail({ project, onUpdate, onClose, onDelete }: ProjectDetailProps) {
  const { toast } = useToast()
  const { currentSession, startSession, endSession, getTotalTimeForProject } = useWorkSession()
  const [activeTab, setActiveTab] = useState("overview")
  const [progress, setProgress] = useState(project.progress)
  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoadingTasks, setIsLoadingTasks] = useState(true)
  const [newTaskText, setNewTaskText] = useState("")
  const [notes, setNotes] = useState<ProjectNote[]>([])
  const [currentNote, setCurrentNote] = useState<ProjectNote | null>(null)
  const [noteContent, setNoteContent] = useState("")
  const [isSavingNote, setIsSavingNote] = useState(false)
  const [files, setFiles] = useState<ProjectFile[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isEditingProject, setIsEditingProject] = useState(false)
  const [editedProject, setEditedProject] = useState<Project>({ ...project })
  const [isDeleting, setIsDeleting] = useState(false)

  // Load tasks for this project
  useEffect(() => {
    let ignore = false

    const loadTasks = () => {
      setIsLoadingTasks(true)
      try {
        const allTasks = storage.get<Task[]>(TASKS_STORAGE_KEY, [], false)
        const projectTasks = allTasks.filter((task) => task.projectId === project.id)
        if (!ignore) {
          setTasks(projectTasks)
        }
      } catch (error) {
        console.error("Error loading tasks:", error)
        setError("Failed to load tasks. Please try again.")
        toast({
          title: "Error",
          description: "Failed to load tasks. Please try again.",
          variant: "destructive",
        })
      } finally {
        if (!ignore) {
          setIsLoadingTasks(false)
        }
      }
    }

    loadTasks()

    return () => {
      ignore = true
    }
  }, [project.id, toast])

  // Load notes for this project
  useEffect(() => {
    const loadNotes = () => {
      try {
        const allNotes = storage.get<ProjectNote[]>(NOTES_STORAGE_KEY, [], false)
        const projectNotes = allNotes.filter((note) => note.projectId === project.id)
        setNotes(projectNotes)

        // Set the most recent note as current if available
        if (projectNotes.length > 0) {
          const sortedNotes = [...projectNotes].sort(
            (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
          )
          setCurrentNote(sortedNotes[0])
          setNoteContent(sortedNotes[0].content)
        }
      } catch (error) {
        console.error("Error loading notes:", error)
        setError("Failed to load notes. Please try again.")
      }
    }

    loadNotes()
  }, [project.id])

  // Load files for this project
  useEffect(() => {
    const loadFiles = () => {
      try {
        const allFiles = storage.get<ProjectFile[]>(FILES_STORAGE_KEY, [], false)
        const projectFiles = allFiles.filter((file) => file.projectId === project.id)
        setFiles(projectFiles)
      } catch (error) {
        console.error("Error loading files:", error)
      }
    }

    loadFiles()
  }, [project.id])

  // Update project mutation
  const updateProjectMutation = useMutation({
    mutationFn: async (data: Partial<Project>) => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500))
      return { ...project, ...data }
    },
    onSuccess: (data) => {
      onUpdate(data)
      toast({
        title: "Project updated",
        description: "Project changes have been saved.",
      })
    },
    onError: (error) => {
      console.error("Error updating project:", error)
      setError("Failed to update project. Please try again.")
      toast({
        title: "Error",
        description: "Failed to update project. Please try again.",
        variant: "destructive",
      })
    },
  })

  // Format time logged
  const formatTimeLogged = (seconds = 0) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours}h ${minutes}m ${secs}s`
  }

  // Calculate days until deadline
  const getDaysUntilDeadline = () => {
    if (!project.deadline) return "No deadline"

    const deadline = new Date(project.deadline)
    const now = new Date()
    const diffTime = deadline.getTime() - now.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

    return diffDays > 0 ? `Due in ${diffDays} days` : "Overdue"
  }

  // Handle session toggling
  const handleSessionToggle = async () => {
    try {
      if (currentSession?.projectId === project.id) {
        await endSession()
        toast({
          title: "Session ended",
          description: "Your work session has been saved.",
        })
      } else {
        await startSession(project.id, "focus")
        toast({
          title: "Session started",
          description: "Your work session has begun.",
        })
      }
    } catch (error) {
      console.error("Session error:", error)
      setError("Failed to manage work session. Please try again.")
      toast({
        title: "Error",
        description: "Failed to manage work session",
        variant: "destructive",
      })
    }
  }

  // Handle progress update
  const handleProgressUpdate = () => {
    updateProjectMutation.mutate({ progress })
  }

  // Add a new task
  const handleAddTask = () => {
    if (!newTaskText.trim()) return

    const newTask: Task = {
      id: Date.now().toString(),
      text: newTaskText,
      completed: false,
      projectId: project.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    const updatedTasks = [...tasks, newTask]
    setTasks(updatedTasks)

    // Save to storage
    const allTasks = storage.get<Task[]>(TASKS_STORAGE_KEY, [], false)
    const otherTasks = allTasks.filter((task) => task.projectId !== project.id)
    storage.set<Task[]>(TASKS_STORAGE_KEY, [...otherTasks, ...updatedTasks], false)

    setNewTaskText("")

    toast({
      title: "Task added",
      description: "New task has been added to the project.",
    })
  }

  // Toggle task completion
  const handleToggleTask = (taskId: string) => {
    const updatedTasks = tasks.map((task) =>
      task.id === taskId
        ? {
            ...task,
            completed: !task.completed,
            updatedAt: new Date().toISOString(),
          }
        : task,
    )
    setTasks(updatedTasks)

    // Save to storage
    const allTasks = storage.get<Task[]>(TASKS_STORAGE_KEY, [], false)
    const otherTasks = allTasks.filter((task) => task.projectId !== project.id)
    storage.set<Task[]>(TASKS_STORAGE_KEY, [...otherTasks, ...updatedTasks], false)

    // Update project progress based on completed tasks
    const completedCount = updatedTasks.filter((task) => task.completed).length
    const newProgress = updatedTasks.length > 0 ? Math.round((completedCount / updatedTasks.length) * 100) : 0

    setProgress(newProgress)
    updateProjectMutation.mutate({ progress: newProgress })
  }

  // Delete a task
  const handleDeleteTask = (taskId: string) => {
    const updatedTasks = tasks.filter((task) => task.id !== taskId)
    setTasks(updatedTasks)

    // Save to storage
    const allTasks = storage.get<Task[]>(TASKS_STORAGE_KEY, [], false)
    const otherTasks = allTasks.filter((task) => task.projectId !== project.id)
    storage.set<Task[]>(TASKS_STORAGE_KEY, [...otherTasks, ...updatedTasks], false)

    toast({
      title: "Task deleted",
      description: "Task has been removed from the project.",
    })

    // Update project progress based on completed tasks
    const completedCount = updatedTasks.filter((task) => task.completed).length
    const newProgress = updatedTasks.length > 0 ? Math.round((completedCount / updatedTasks.length) * 100) : 0

    setProgress(newProgress)
    updateProjectMutation.mutate({ progress: newProgress })
  }

  // Create a new note
  const handleCreateNote = () => {
    const newNote: ProjectNote = {
      id: Date.now().toString(),
      content: "",
      projectId: project.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    const updatedNotes = [...notes, newNote]
    setNotes(updatedNotes)
    setCurrentNote(newNote)
    setNoteContent("")

    // Save to storage
    const allNotes = storage.get<ProjectNote[]>(NOTES_STORAGE_KEY, [], false)
    const otherNotes = allNotes.filter((note) => note.projectId !== project.id)
    storage.set<ProjectNote[]>(NOTES_STORAGE_KEY, [...otherNotes, ...updatedNotes], false)
  }

  // Save current note
  const handleSaveNote = () => {
    if (!currentNote) return

    setIsSavingNote(true)

    try {
      const updatedNote: ProjectNote = {
        ...currentNote,
        content: noteContent,
        updatedAt: new Date().toISOString(),
      }

      const updatedNotes = notes.map((note) => (note.id === currentNote.id ? updatedNote : note))

      setNotes(updatedNotes)
      setCurrentNote(updatedNote)

      // Save to storage
      const allNotes = storage.get<ProjectNote[]>(NOTES_STORAGE_KEY, [], false)
      const otherNotes = allNotes.filter((note) => note.projectId !== project.id)
      storage.set<ProjectNote[]>(NOTES_STORAGE_KEY, [...otherNotes, ...updatedNotes], false)

      toast({
        title: "Note saved",
        description: "Your note has been saved successfully.",
      })
    } catch (error) {
      console.error("Error saving note:", error)
      setError("Failed to save note. Please try again.")
      toast({
        title: "Error",
        description: "Failed to save note. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSavingNote(false)
    }
  }

  // Select a note
  const handleSelectNote = (note: ProjectNote) => {
    // Save current note first if it exists and has changed
    if (currentNote && noteContent !== currentNote.content) {
      handleSaveNote()
    }

    setCurrentNote(note)
    setNoteContent(note.content)
  }

  // Delete current note
  const handleDeleteNote = () => {
    if (!currentNote) return

    const updatedNotes = notes.filter((note) => note.id !== currentNote.id)
    setNotes(updatedNotes)

    // Save to storage
    const allNotes = storage.get<ProjectNote[]>(NOTES_STORAGE_KEY, [], false)
    const otherNotes = allNotes.filter((note) => note.projectId !== project.id)
    storage.set<ProjectNote[]>(NOTES_STORAGE_KEY, [...otherNotes, ...updatedNotes], false)

    // Select another note if available
    if (updatedNotes.length > 0) {
      setCurrentNote(updatedNotes[0])
      setNoteContent(updatedNotes[0].content)
    } else {
      setCurrentNote(null)
      setNoteContent("")
    }

    toast({
      title: "Note deleted",
      description: "Your note has been deleted.",
    })
  }

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return

    setIsUploading(true)

    try {
      const file = e.target.files[0]

      // In a real app, this would upload the file to a server
      // For demo, we'll simulate a file upload
      setTimeout(() => {
        const newFile: ProjectFile = {
          id: Date.now().toString(),
          name: file.name,
          type: file.type,
          size: file.size,
          url: URL.createObjectURL(file), // In a real app, this would be a server URL
          projectId: project.id,
          createdAt: new Date().toISOString(),
        }

        const updatedFiles = [...files, newFile]
        setFiles(updatedFiles)

        // Save to storage
        const allFiles = storage.get<ProjectFile[]>(FILES_STORAGE_KEY, [], false)
        const otherFiles = allFiles.filter((f) => f.projectId !== project.id)
        storage.set<ProjectFile[]>(FILES_STORAGE_KEY, [...otherFiles, ...updatedFiles], false)

        // Update project files count
        updateProjectMutation.mutate({ files: updatedFiles.length })

        toast({
          title: "File uploaded",
          description: `${file.name} has been uploaded successfully.`,
        })

        setIsUploading(false)
      }, 1500)
    } catch (error) {
      console.error("Error uploading file:", error)
      setError("Failed to upload file. Please try again.")
      toast({
        title: "Error",
        description: "Failed to upload file. Please try again.",
        variant: "destructive",
      })
      setIsUploading(false)
    }
  }

  // Delete a file
  const handleDeleteFile = (fileId: string) => {
    const updatedFiles = files.filter((file) => file.id !== fileId)
    setFiles(updatedFiles)

    // Save to storage
    const allFiles = storage.get<ProjectFile[]>(FILES_STORAGE_KEY, [], false)
    const otherFiles = allFiles.filter((file) => file.projectId !== project.id)
    storage.set<ProjectFile[]>(FILES_STORAGE_KEY, [...otherFiles, ...updatedFiles], false)

    // Update project files count
    updateProjectMutation.mutate({ files: updatedFiles.length })

    toast({
      title: "File deleted",
      description: "File has been removed from the project.",
    })
  }

  // Handle AI-generated task suggestions
  const handleAITaskSuggestions = (tasksText: string) => {
    // Parse the bulleted list into individual tasks
    const taskLines = tasksText
      .split("\n")
      .filter((line) => line.trim().startsWith("-") || line.trim().startsWith("•"))
      .map((line) => line.replace(/^[-•]\s*/, "").trim())
      .filter((line) => line.length > 0)

    if (taskLines.length === 0) {
      toast({
        title: "No tasks found",
        description: "The AI didn't generate any recognizable tasks. Please try again.",
        variant: "destructive",
      })
      return
    }

    // Create new tasks
    const newTasks = taskLines.map((text) => ({
      id: Date.now() + Math.random().toString(36).substring(2, 9),
      text,
      completed: false,
      projectId: project.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }))

    const updatedTasks = [...tasks, ...newTasks]
    setTasks(updatedTasks)

    // Save to storage
    const allTasks = storage.get<Task[]>(TASKS_STORAGE_KEY, [], false)
    const otherTasks = allTasks.filter((task) => task.projectId !== project.id)
    storage.set<Task[]>(TASKS_STORAGE_KEY, [...otherTasks, ...updatedTasks], false)

    toast({
      title: "Tasks generated",
      description: `${newTasks.length} tasks have been added to your project.`,
    })
  }

  // Save edited project
  const handleSaveProject = () => {
    updateProjectMutation.mutate(editedProject)
    setIsEditingProject(false)
  }

  // Delete project
  const handleDeleteProject = () => {
    setIsDeleting(true)

    try {
      // Delete all project-related data
      const allTasks = storage.get<Task[]>(TASKS_STORAGE_KEY, [], false)
      const tasksWithoutProject = allTasks.filter((task) => task.projectId !== project.id)
      storage.set<Task[]>(TASKS_STORAGE_KEY, tasksWithoutProject, false)

      const allNotes = storage.get<ProjectNote[]>(NOTES_STORAGE_KEY, [], false)
      const notesWithoutProject = allNotes.filter((note) => note.projectId !== project.id)
      storage.set<ProjectNote[]>(NOTES_STORAGE_KEY, notesWithoutProject, false)

      const allFiles = storage.get<ProjectFile[]>(FILES_STORAGE_KEY, [], false)
      const filesWithoutProject = allFiles.filter((file) => file.projectId !== project.id)
      storage.set<ProjectFile[]>(FILES_STORAGE_KEY, filesWithoutProject, false)

      // Call onDelete callback if provided
      if (onDelete) {
        onDelete(project.id)
      }

      toast({
        title: "Project deleted",
        description: "The project and all associated data have been deleted.",
      })

      // Go back to projects list
      onClose()
    } catch (error) {
      console.error("Error deleting project:", error)
      setError("Failed to delete project. Please try again.")
      toast({
        title: "Error",
        description: "Failed to delete project. Please try again.",
        variant: "destructive",
      })
      setIsDeleting(false)
    }
  }

  // Get session elapsed time
  const getSessionElapsed = () => {
    if (!currentSession || currentSession.projectId !== project.id) return 0

    const startTime = new Date(currentSession.startTime).getTime()
    const now = new Date().getTime()
    const elapsedMs = now - startTime
    return Math.floor(elapsedMs / 1000) // Convert to seconds
  }

  // Get total time logged for this project
  const totalTimeLogged = getTotalTimeForProject(project.id)

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex items-start justify-between">
        {isEditingProject ? (
          <div className="space-y-4 w-full max-w-md">
            <div>
              <Label htmlFor="project-name">Project Name</Label>
              <Input
                id="project-name"
                value={editedProject.name}
                onChange={(e) => setEditedProject({ ...editedProject, name: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="project-description">Description</Label>
              <Textarea
                id="project-description"
                value={editedProject.description}
                onChange={(e) => setEditedProject({ ...editedProject, description: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="project-deadline">Deadline</Label>
              <Input
                id="project-deadline"
                type="date"
                value={editedProject.deadline || ""}
                onChange={(e) => setEditedProject({ ...editedProject, deadline: e.target.value })}
                className="mt-1"
              />
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setIsEditingProject(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveProject}>Save Changes</Button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center">
              <span className="material-icons mr-2 text-2xl" style={{ color: project.colorCode }}>
                {project.icon}
              </span>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{project.name}</h1>
            </div>
            <p className="mt-1 text-gray-500 dark:text-gray-400">{project.description}</p>
          </div>
        )}
        <Button variant="outline" onClick={onClose}>
          <span className="material-icons mr-1">arrow_back</span>
          Back to Projects
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-3">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="ai-assistant">AI Assistant</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Project Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-4">
                    <div className="flex-1 mr-4">
                      <Progress value={progress} className="h-4" />
                    </div>
                    <div className="w-20">
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={progress}
                        onChange={(e) => setProgress(Number.parseInt(e.target.value))}
                      />
                    </div>
                    <Button className="ml-2" onClick={handleProgressUpdate} disabled={updateProjectMutation.isPending}>
                      {updateProjectMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Update"}
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Status</p>
                      <p className="font-medium text-gray-900 dark:text-white">
                        <Badge
                          className={`${
                            progress >= 60
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                              : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                          }`}
                        >
                          {progress >= 60 ? "On track" : "Needs attention"}
                        </Badge>
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Type</p>
                      <p className="font-medium text-gray-900 dark:text-white capitalize">{project.type}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Deadline</p>
                      <p className="font-medium text-gray-900 dark:text-white">{getDaysUntilDeadline()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Time Logged</p>
                      <p className="font-medium text-gray-900 dark:text-white">{formatTimeLogged(totalTimeLogged)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Tasks</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Add new task..."
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      className="w-64"
                    />
                    <Button size="sm" onClick={handleAddTask} disabled={!newTaskText.trim()}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoadingTasks ? (
                    <div className="flex justify-center py-4">
                      <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
                    </div>
                  ) : tasks.length > 0 ? (
                    <div className="space-y-2">
                      {tasks.map((task) => (
                        <div key={task.id} className="flex items-center justify-between p-2 border rounded-md">
                          <div className="flex items-center">
                            <Checkbox
                              id={`task-${task.id}`}
                              checked={task.completed}
                              onCheckedChange={() => handleToggleTask(task.id)}
                              className="mr-2"
                            />
                            <Label
                              htmlFor={`task-${task.id}`}
                              className={task.completed ? "line-through text-gray-400" : ""}
                            >
                              {task.text}
                            </Label>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteTask(task.id)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 text-gray-500">
                      <FileText className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p>No tasks yet. Add your first task to get started.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Content Tab */}
            <TabsContent value="content" className="space-y-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Project Notes</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" onClick={handleCreateNote}>
                      <Plus className="h-4 w-4 mr-1" />
                      New Note
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-1 border-r pr-4">
                      {notes.length > 0 ? (
                        <div className="space-y-2">
                          {notes.map((note) => (
                            <div
                              key={note.id}
                              className={`p-2 rounded cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 ${
                                currentNote?.id === note.id ? "bg-gray-100 dark:bg-gray-800" : ""
                              }`}
                              onClick={() => handleSelectNote(note)}
                            >
                              <p className="font-medium truncate">{note.content.split("\n")[0] || "Untitled Note"}</p>
                              <p className="text-xs text-gray-500">{new Date(note.updatedAt).toLocaleDateString()}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-6 text-gray-500">
                          <p>No notes yet</p>
                        </div>
                      )}
                    </div>
                    <div className="md:col-span-3">
                      {currentNote ? (
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <p className="text-sm text-gray-500">
                              Last updated: {new Date(currentNote.updatedAt).toLocaleString()}
                            </p>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm" onClick={handleDeleteNote} className="text-red-500">
                                <Trash2 className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                              <Button size="sm" onClick={handleSaveNote} disabled={isSavingNote}>
                                {isSavingNote ? (
                                  <Loader2 className="h-4 w-4 animate-spin mr-1" />
                                ) : (
                                  <Save className="h-4 w-4 mr-1" />
                                )}
                                Save
                              </Button>
                            </div>
                          </div>
                          <Textarea
                            value={noteContent}
                            onChange={(e) => setNoteContent(e.target.value)}
                            placeholder="Enter your note here..."
                            className="min-h-[300px]"
                          />
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-64 text-center">
                          <FileText className="h-12 w-12 text-gray-300 mb-2" />
                          <p className="text-gray-500">Select a note or create a new one</p>
                          <Button variant="outline" className="mt-4" onClick={handleCreateNote}>
                            <Plus className="h-4 w-4 mr-1" />
                            Create Note
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Files & Resources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6">
                    <Upload className="h-12 w-12 text-gray-300 mb-2" />
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Drag and drop files here or click to browse
                    </p>
                    <div className="mt-4">
                      <input
                        type="file"
                        id="file-upload"
                        className="hidden"
                        onChange={handleFileUpload}
                        disabled={isUploading}
                      />
                      <label htmlFor="file-upload">
                        <Button variant="outline" as="span" disabled={isUploading}>
                          {isUploading ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              Uploading...
                            </>
                          ) : (
                            <>
                              <Upload className="h-4 w-4 mr-2" />
                              Upload Files
                            </>
                          )}
                        </Button>
                      </label>
                    </div>
                  </div>

                  {files.length > 0 ? (
                    <div className="mt-6">
                      <h3 className="font-medium text-gray-900 dark:text-white mb-4">
                        Uploaded Files ({files.length})
                      </h3>
                      <div className="space-y-2">
                        {files.map((file) => (
                          <div key={file.id} className="flex items-center justify-between p-2 border rounded-md">
                            <div className="flex items-center">
                              <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded mr-3">
                                <FileText className="h-4 w-4 text-gray-500" />
                              </div>
                              <div>
                                <p className="font-medium">{file.name}</p>
                                <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm" onClick={() => window.open(file.url, "_blank")}>
                                View
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteFile(file.id)}
                                className="text-gray-400 hover:text-red-500"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
                      No files uploaded yet
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* AI Assistant Tab */}
            <TabsContent value="ai-assistant">
              <ChatInterface projectId={project.id} embedded={true} onGenerateTasks={handleAITaskSuggestions} />
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Current Session</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center py-6">
              <div className="mb-6">
                {currentSession?.projectId === project.id ? (
                  <Timer
                    duration={60 * 60} // 1 hour in seconds
                    elapsed={getSessionElapsed()}
                    isRunning={true}
                    size="lg"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                    <Clock className="h-8 w-8 text-gray-400" />
                  </div>
                )}
              </div>

              <div className="text-center mb-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {currentSession?.projectId === project.id ? "Session in progress" : "No active session"}
                </p>
              </div>

              <Button
                onClick={handleSessionToggle}
                variant={currentSession?.projectId === project.id ? "destructive" : "default"}
                className="w-full"
              >
                {currentSession?.projectId === project.id ? (
                  <>
                    <Square className="h-4 w-4 mr-2" />
                    End Session
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Start Session
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" onClick={() => setIsEditingProject(true)}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Project
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => {
                  const date = prompt("Enter deadline (YYYY-MM-DD):", project.deadline || "")
                  if (date) {
                    updateProjectMutation.mutate({ deadline: date })
                  }
                }}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Set Deadline
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Share className="h-4 w-4 mr-2" />
                Share
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-destructive hover:text-destructive">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Are you sure?</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleDeleteProject} disabled={isDeleting}>
                    {isDeleting ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Deleting...
                      </>
                    ) : (
                      <>
                        <Trash2 className="h-4 w-4 mr-2" />
                        Yes, delete project
                      </>
                    )}
                  </DropdownMenuItem>
                  <DropdownMenuItem>Cancel</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

