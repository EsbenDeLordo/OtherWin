"use client"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Recommendation {
  id: number
  title: string
  description: string
  type: string
  icon: string
  actionText: string
  secondaryActionText?: string
  isCompleted: boolean
}

export function WinDryftRecommendations() {
  // Sample recommendations for demo
  const sampleRecommendations = [
    {
      id: 1,
      title: "Take a hydration break",
      description: "Drink 16oz of water to maintain optimal cognitive function",
      type: "hydration",
      icon: "water_drop",
      actionText: "Drink water now",
      secondaryActionText: "Remind me later",
      isCompleted: false,
    },
    {
      id: 2,
      title: "NSDR Session",
      description: "15-minute non-sleep deep rest to restore focus and energy",
      type: "nsdr",
      icon: "self_improvement",
      actionText: "Start session",
      secondaryActionText: "Skip for now",
      isCompleted: false,
    },
  ]

  // Filter out completed recommendations
  const activeRecommendations = sampleRecommendations.filter((rec) => !rec.isCompleted)

  const handleRecommendationAction = (recommendationId: number, isCompleted: boolean) => {
    // In a real app, this would update the recommendation status
    console.log(`Recommendation ${recommendationId} marked as ${isCompleted ? "completed" : "skipped"}`)
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between px-6 py-5 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between w-full">
          <CardTitle className="text-lg font-medium">Pocket WinDryft Mode</CardTitle>
          <Badge variant="outline" className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300">
            <span className="material-icons text-xs mr-1">auto_awesome</span>
            Personalized
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="px-6 py-5 divide-y divide-gray-200 dark:divide-gray-700">
        {activeRecommendations.length > 0 ? (
          activeRecommendations.map((recommendation) => (
            <div key={recommendation.id} className="py-4 first:pt-0">
              <div className="flex items-start">
                <div className="flex-shrink-0 pt-1">
                  <span className="material-icons text-accent">{recommendation.icon}</span>
                </div>
                <div className="ml-3 flex-1">
                  <h3 className="text-md font-medium text-gray-900 dark:text-white">{recommendation.title}</h3>
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{recommendation.description}</p>
                  <div className="mt-3 flex">
                    <Button
                      size="sm"
                      className="rounded-full"
                      style={{
                        backgroundColor:
                          recommendation.type === "nsdr"
                            ? "#8B5CF6"
                            : recommendation.type === "hydration"
                              ? "#10B981"
                              : "#3B82F6",
                      }}
                      onClick={() => handleRecommendationAction(recommendation.id, true)}
                    >
                      {recommendation.actionText}
                    </Button>

                    {recommendation.secondaryActionText && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="ml-3 rounded-full"
                        onClick={() => handleRecommendationAction(recommendation.id, false)}
                      >
                        {recommendation.secondaryActionText}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="py-6 text-center">
            <span className="material-icons text-3xl text-gray-400 mb-2">check_circle</span>
            <p className="text-gray-500 dark:text-gray-400">All caught up! No active recommendations.</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

