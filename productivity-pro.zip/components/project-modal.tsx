"use client"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useProjects } from "@/context/ProjectContext"
import { useToast } from "@/hooks/use-toast"
import { useState, useEffect, useRef } from "react"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Project schema
const formSchema = z.object({
  name: z.string().min(2, { message: "Project name must be at least 2 characters" }),
  description: z.string().optional(),
  type: z.string(),
  deadline: z.string().optional(),
  userId: z.number(),
  aiAssistanceEnabled: z.boolean(),
  colorCode: z.string(),
  icon: z.string(),
})

type FormData = z.infer<typeof formSchema>

interface Project {
  id: number
  name: string
  description: string
  type: string
  progress: number
  deadline?: string
  timeLogged: number
  files: number
  colorCode: string
  icon: string
  userId: number
  aiAssistanceEnabled?: boolean
}

interface ProjectModalProps {
  isOpen: boolean
  onClose: () => void
  project?: Project
}

export function ProjectModal({ isOpen, onClose, project }: ProjectModalProps) {
  const { createProject } = useProjects()
  const { toast } = useToast()
  const userId = 1 // For demo purposes
  const [isSubmitting, setIsSubmitting] = useState(false)
  const formInitialized = useRef(false)

  // Default values
  const defaultValues = {
    name: "",
    description: "",
    type: "video",
    userId,
    deadline: "",
    aiAssistanceEnabled: true,
    colorCode: "#3B82F6",
    icon: "videocam",
  }

  // Form setup
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: project
      ? {
          ...project,
          deadline: project.deadline || "",
        }
      : defaultValues,
  })

  // Reset form when modal opens/closes, but only once
  useEffect(() => {
    if (isOpen && !formInitialized.current) {
      form.reset(
        project
          ? {
              ...project,
              deadline: project.deadline || "",
            }
          : defaultValues,
      )
      formInitialized.current = true
    } else if (!isOpen) {
      formInitialized.current = false
    }
  }, [isOpen, form, project])

  const onSubmit = async (data: FormData) => {
    if (isSubmitting) return

    setIsSubmitting(true)

    try {
      if (project) {
        // Update existing project
        toast({
          title: "Project updated",
          description: "Project has been updated successfully.",
        })
      } else {
        // Create new project
        await createProject({
          ...data,
          status: "active",
          progress: 0,
          files: 0,
          timeLogged: 0,
        })
        toast({
          title: "Project created",
          description: "Your new project has been created successfully.",
        })
      }

      onClose()
    } catch (error) {
      console.error("Failed to save project:", error)
      toast({
        title: "Error",
        description: `Failed to ${project ? "update" : "create"} project. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center">
            <div className="mr-4 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900">
              <span className="material-icons text-primary dark:text-blue-300">add_task</span>
            </div>
            <div>
              <DialogTitle className="text-lg">{project ? "Edit Project" : "Create New Project"}</DialogTitle>
              <DialogDescription>
                {project ? "Update your project details" : "Set up a new project with templates and AI assistance"}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Name</FormLabel>
                  <FormControl>
                    <Input placeholder="New project name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select project type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="video">Video Production</SelectItem>
                      <SelectItem value="research">Research Paper</SelectItem>
                      <SelectItem value="guide">Practical Guide</SelectItem>
                      <SelectItem value="podcast">Podcast Episode</SelectItem>
                      <SelectItem value="custom">Custom Template</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Brief Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="What's this project about?" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="deadline"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Deadline</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="aiAssistanceEnabled"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={(checked) => {
                        field.onChange(checked === true)
                      }}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable AI assistance</FormLabel>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Let AI help you with research, drafting, and organization
                    </p>
                  </div>
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {project ? "Update Project" : "Create Project"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

