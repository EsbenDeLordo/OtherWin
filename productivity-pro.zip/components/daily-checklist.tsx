"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"

interface ChecklistItem {
  id: string
  text: string
  checked: boolean
  category: "health" | "work" | "personal"
}

export function DailyChecklist() {
  const [items, setItems] = useState<ChecklistItem[]>([
    { id: "1", text: "Morning sunlight exposure (10-30 mins)", checked: false, category: "health" },
    { id: "2", text: "Take Omega-3 supplement", checked: false, category: "health" },
    { id: "3", text: "Drink 16oz water upon waking", checked: false, category: "health" },
    { id: "4", text: "Exercise/movement (30+ mins)", checked: false, category: "health" },
    { id: "5", text: "Cold exposure (2-5 mins)", checked: false, category: "health" },
    { id: "6", text: "Meditation/breathwork (10-20 mins)", checked: false, category: "health" },
  ])

  const toggleItem = (id: string) => {
    setItems(items.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item)))
  }

  const resetChecklist = () => {
    setItems(items.map((item) => ({ ...item, checked: false })))
  }

  const addTask = () => {
    // Implementation for adding a new task
  }

  // Calculate completion stats
  const completed = items.filter((item) => item.checked).length
  const total = items.length
  const completionPercentage = total > 0 ? Math.round((completed / total) * 100) : 0

  // Get current date
  const today = new Date()
  const formattedDate = today.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  })

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle>Daily Checklist</CardTitle>
        <div className="text-sm text-muted-foreground">
          {completed}/{total} • {completionPercentage}%
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">{formattedDate}</p>

        <div className="mb-2">
          <div className="flex items-center text-sm font-medium text-green-500 mb-2">
            <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
            Health
          </div>

          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Checkbox
                    id={`item-${item.id}`}
                    checked={item.checked}
                    onCheckedChange={() => toggleItem(item.id)}
                    className="mr-2"
                  />
                  <label htmlFor={`item-${item.id}`} className="text-sm">
                    {item.text}
                  </label>
                </div>
                <button className="text-gray-400 hover:text-gray-600">
                  <span className="material-icons text-lg">more_vert</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-between mt-6">
          <Button variant="outline" size="sm" onClick={resetChecklist}>
            Reset
          </Button>
          <Button size="sm" onClick={addTask}>
            <span className="material-icons text-sm mr-1">add</span>
            Add Task
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

