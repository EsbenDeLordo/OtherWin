"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

interface TimerProps {
  duration: number
  elapsed: number
  isRunning: boolean
  size?: "sm" | "md" | "lg"
  showText?: boolean
  onComplete?: () => void
}

export function Timer({ duration, elapsed, isRunning, size = "md", showText = true, onComplete }: TimerProps) {
  const [currentElapsed, setCurrentElapsed] = useState(elapsed)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isRunning) {
      interval = setInterval(() => {
        setCurrentElapsed((prev) => {
          const next = prev + 1
          if (next >= duration && onComplete) {
            onComplete()
          }
          return next
        })
      }, 1000)
    }

    return () => clearInterval(interval)
  }, [isRunning, duration, onComplete])

  useEffect(() => {
    setCurrentElapsed(elapsed)
  }, [elapsed])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const percentage = Math.min(100, (currentElapsed / duration) * 100)
  const remaining = Math.max(0, duration - currentElapsed)

  const sizeClasses = {
    sm: "h-10 w-10",
    md: "h-16 w-16",
    lg: "h-24 w-24",
  }

  const textSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  }

  return (
    <div className="relative flex items-center justify-center">
      <svg className={cn("transform -rotate-90", sizeClasses[size])} viewBox="0 0 100 100">
        {/* Background circle */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="none"
          stroke="currentColor"
          className="text-gray-200 dark:text-gray-700"
          strokeWidth="10"
        />
        {/* Progress circle */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="none"
          stroke="currentColor"
          className="text-primary"
          strokeWidth="10"
          strokeDasharray="283"
          strokeDashoffset={283 - (283 * percentage) / 100}
          strokeLinecap="round"
        />
      </svg>
      {showText && (
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={cn("font-medium", textSizeClasses[size])}>{formatTime(remaining)}</span>
        </div>
      )}
    </div>
  )
}

