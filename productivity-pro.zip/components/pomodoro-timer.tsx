"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function PomodoroTimer() {
  const [activeTab, setActiveTab] = useState("focus")
  const [timeLeft, setTimeLeft] = useState(25 * 60) // 25 minutes in seconds
  const [isRunning, setIsRunning] = useState(false)
  const [completedToday, setCompletedToday] = useState(0)

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Format time as display (25:00)
  const displayTime = () => {
    const mins = Math.floor(timeLeft / 60)
    const secs = timeLeft % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setIsRunning(false)

    if (value === "focus") {
      setTimeLeft(25 * 60) // 25 minutes
    } else if (value === "short") {
      setTimeLeft(5 * 60) // 5 minutes
    } else {
      setTimeLeft(15 * 60) // 15 minutes
    }
  }

  // Toggle timer
  const toggleTimer = () => {
    setIsRunning(!isRunning)
  }

  // Reset timer
  const resetTimer = () => {
    setIsRunning(false)
    if (activeTab === "focus") {
      setTimeLeft(25 * 60)
    } else if (activeTab === "short") {
      setTimeLeft(5 * 60)
    } else {
      setTimeLeft(15 * 60)
    }
  }

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      setIsRunning(false)
      if (activeTab === "focus") {
        setCompletedToday(completedToday + 1)
      }
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, timeLeft, activeTab, completedToday])

  return (
    <Card className="bg-red-50 dark:bg-red-900/10 border-red-100 dark:border-red-800">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-medium">Pomodoro Timer</h2>
          <button className="text-gray-500 hover:text-gray-700">
            <span className="material-icons">settings</span>
          </button>
        </div>

        <p className="text-gray-500 mb-4">Stay focused and take structured breaks</p>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-6">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="focus">Focus</TabsTrigger>
            <TabsTrigger value="short">Short Break</TabsTrigger>
            <TabsTrigger value="long">Long Break</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="text-center mb-6">
          <div className="text-6xl font-bold mb-6">{displayTime()}</div>

          <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full mb-8">
            <div
              className="bg-red-500 h-2 rounded-full"
              style={{
                width: `${(timeLeft / (activeTab === "focus" ? 25 * 60 : activeTab === "short" ? 5 * 60 : 15 * 60)) * 100}%`,
              }}
            ></div>
          </div>

          <div className="flex justify-center space-x-4">
            <Button
              className="w-12 h-12 rounded-full bg-blue-500 hover:bg-blue-600 flex items-center justify-center"
              onClick={toggleTimer}
            >
              <span className="material-icons">{isRunning ? "pause" : "play_arrow"}</span>
            </Button>

            <Button
              className="w-12 h-12 rounded-full bg-gray-200 hover:bg-gray-300 text-gray-700 flex items-center justify-center"
              onClick={resetTimer}
            >
              <span className="material-icons">refresh</span>
            </Button>
          </div>
        </div>

        <div className="flex justify-between text-sm text-gray-500">
          <div className="flex items-center">
            <span className="material-icons text-sm mr-1">timer</span>
            <span>25 min focus</span>
          </div>
          <div>
            <span>{completedToday} completed today</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

