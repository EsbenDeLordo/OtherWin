"use client"
import { usePathname } from "next/navigation"
import { useTheme } from "@/hooks/use-theme"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Menu, Sun, Moon } from "lucide-react"
import { Sidebar } from "@/components/sidebar"

interface User {
  id: number
  name: string
  email: string
  avatar?: string
}

interface MobileHeaderProps {
  user: User
}

export function MobileHeader({ user }: MobileHeaderProps) {
  const pathname = usePathname()
  const { theme, toggleTheme } = useTheme()

  // Based on the current location, get the title
  const getTitle = () => {
    switch (pathname) {
      case "/":
        return "Dashboard"
      case "/projects":
        return "Projects"
      case "/analytics":
        return "Analytics"
      case "/assistant":
        return "AI Assistant"
      case "/recommendations":
        return "Recommendations"
      case "/content-tools":
        return "Content Tools"
      case "/automation":
        return "Automation"
      default:
        return "ProductivityPro"
    }
  }

  return (
    <div className="md:hidden fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 z-10">
      <div className="flex items-center justify-between px-4 h-16">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64">
            <Sidebar user={user} />
          </SheetContent>
        </Sheet>
        <h1 className="text-lg font-semibold">
          <span className="text-primary">Productivity</span>Pro
        </h1>
        <div className="flex items-center">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="mr-2">
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <span className="text-primary font-medium">{user.name.charAt(0)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

