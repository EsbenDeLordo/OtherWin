"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { useProjects } from "@/context/ProjectContext"

export function Sidebar() {
  const pathname = usePathname()
  const { projects } = useProjects()

  // Get recent projects (limit to 5)
  const recentProjects = projects.slice(0, 5)

  const navItems = [
    {
      title: "Dashboard",
      href: "/",
      icon: "dashboard",
    },
    {
      title: "Projects",
      href: "/projects",
      icon: "folder",
    },
    {
      title: "Analytics",
      href: "/analytics",
      icon: "analytics",
    },
    {
      title: "AI Assistant",
      href: "/assistant",
      icon: "smart_toy",
    },
    {
      title: "Recommendations",
      href: "/recommendations",
      icon: "lightbulb",
    },
    {
      title: "Content Tools",
      href: "/content-tools",
      icon: "description",
    },
    {
      title: "Automation",
      href: "/automation",
      icon: "settings",
    },
  ]

  return (
    <div className="flex flex-col h-full w-[240px] border-r bg-white dark:bg-gray-950">
      <div className="p-4 border-b">
        <Link href="/" className="flex items-center">
          <span className="text-blue-500 font-bold">Pocket</span>
          <span className="font-bold ml-1">WinDryft Pro</span>
        </Link>
      </div>

      <div className="flex-1 overflow-auto py-2">
        <nav className="grid gap-1 px-2">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium",
                pathname === item.href
                  ? "bg-blue-500 text-white"
                  : "text-gray-500 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-50 dark:hover:bg-gray-800",
              )}
            >
              <span className="material-icons text-[20px]">{item.icon}</span>
              {item.title}
            </Link>
          ))}
        </nav>

        {recentProjects.length > 0 && (
          <div className="mt-6 px-3">
            <h3 className="mb-2 px-2 text-xs font-semibold text-gray-500 dark:text-gray-400">RECENT PROJECTS</h3>
            <nav className="grid gap-1">
              {recentProjects.map((project) => (
                <Link
                  key={project.id}
                  href={`/projects/${project.id}`}
                  className="flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-gray-500 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-50 dark:hover:bg-gray-800"
                >
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  {project.name}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </div>

      <div className="mt-auto p-4 border-t">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
            <span className="text-gray-500 text-xs">TN</span>
          </div>
          <div>
            <p className="text-sm font-medium">Tadeáš Novák</p>
          </div>
        </div>
      </div>
    </div>
  )
}

