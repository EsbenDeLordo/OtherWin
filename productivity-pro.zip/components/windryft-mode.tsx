import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function WinDryftMode() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle>Pocket WinDryft Mode</CardTitle>
          <Badge variant="outline" className="bg-purple-100 text-purple-800 hover:bg-purple-200">
            Personalized
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
            <span className="material-icons text-blue-500">schedule</span>
          </div>
          <div>
            <h3 className="font-medium">Take a strategic break</h3>
            <p className="text-sm text-gray-500">Recommended</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

