"use client"

import { useQuery } from "@tanstack/react-query"
import { useProjects } from "@/context/ProjectContext"
import { useWorkSession } from "@/context/WorkSessionContext"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function Overview() {
  const userId = 1 // For demo purposes
  const { projects } = useProjects()
  const { currentSession, endSession } = useWorkSession()

  // Get the current day's analytics
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics", userId],
    queryFn: () => {
      // Mock data for demo
      return Promise.resolve([
        {
          focusTime: 0,
          flowStates: 0,
          productivity: 0,
        },
      ])
    },
  })

  // Current day productivity info
  const todayAnalytics = analytics?.[0] || {
    focusTime: 0,
    flowStates: 0,
    productivity: 0,
  }

  // Calculate projects status
  const totalProjects = projects.length
  const onTrackProjects = projects.filter((p) => p.progress >= 60).length

  return (
    <>
      {/* Productivity Score */}
      <Card className="bg-blue-50 dark:bg-blue-900/20">
        <CardContent className="p-5 flex items-center">
          <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 rounded-md p-3 mr-4">
            <span className="material-icons text-primary dark:text-blue-300">speed</span>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Productivity Score</h3>
            <p className="text-2xl font-medium text-gray-900 dark:text-white">{todayAnalytics.productivity}%</p>
          </div>
          <div className="ml-auto">
            <Button variant="link" size="sm" className="text-primary">
              View details
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Focus Time */}
      <Card className="bg-green-50 dark:bg-green-900/20">
        <CardContent className="p-5 flex items-center">
          <div className="flex-shrink-0 bg-green-100 dark:bg-green-900 rounded-md p-3 mr-4">
            <span className="material-icons text-green-500 dark:text-green-300">timer</span>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Focus Time Today</h3>
            <p className="text-2xl font-medium text-gray-900 dark:text-white">0h 0m</p>
          </div>
          <div className="ml-auto">
            <Button variant="link" size="sm" className="text-primary">
              View details
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Projects Status */}
      <Card className="bg-purple-50 dark:bg-purple-900/20">
        <CardContent className="p-5 flex items-center">
          <div className="flex-shrink-0 bg-purple-100 dark:bg-purple-900 rounded-md p-3 mr-4">
            <span className="material-icons text-purple-500 dark:text-purple-300">folder</span>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Projects</h3>
            <p className="text-2xl font-medium text-gray-900 dark:text-white">
              {onTrackProjects} / {totalProjects} on track
            </p>
          </div>
          <div className="ml-auto">
            <Button variant="link" size="sm" className="text-primary">
              View all
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Work Session */}
      <Card className="bg-red-50 dark:bg-red-900/20">
        <CardContent className="p-5 flex items-center">
          <div className="flex-shrink-0 bg-red-100 dark:bg-red-900 rounded-md p-3 mr-4">
            <span className="material-icons text-red-500 dark:text-red-300">schedule</span>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Current Session</h3>
            <p className="text-2xl font-medium text-gray-900 dark:text-white">No active session</p>
          </div>
          <div className="ml-auto">
            <Button variant="link" size="sm" className="text-primary">
              <span className="material-icons text-sm mr-1">play_arrow</span>
              Start New Session
            </Button>
          </div>
        </CardContent>
      </Card>
    </>
  )
}

