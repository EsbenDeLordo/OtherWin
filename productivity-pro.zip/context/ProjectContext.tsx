"use client"

import { createContext, useContext, useState, useEffect, useRef, useCallback, type ReactNode } from "react"
import type { Project } from "@/shared/schema"
import storage from "@/lib/storage-simple"

interface ProjectContextType {
  projects: Project[]
  isLoading: boolean
  addProject: (project: Omit<Project, "id">) => void
  updateProject: (id: number, project: Partial<Project>) => void
  deleteProject: (id: number) => void
  createProject: (project: any) => Promise<Project>
  getProject: (id: number) => Project | undefined
  selectedProject: Project | null
  setSelectedProject: (project: Project | null) => void
}

const ProjectContext = createContext<ProjectContextType>({
  projects: [],
  isLoading: false,
  addProject: () => {},
  updateProject: () => {},
  deleteProject: () => {},
  createProject: async () => ({ id: 0 }) as Project,
  getProject: () => undefined,
  selectedProject: null,
  setSelectedProject: () => {},
})

const STORAGE_KEY = "productivity_pro_projects"
const SELECTED_PROJECT_KEY = "productivity_pro_selected_project"

// Sample initial projects if none exist
const initialProjects: Project[] = [
  {
    id: 1,
    name: "Website Redesign",
    description: "Redesign the company website with new branding",
    type: "design",
    progress: 75,
    deadline: "2023-05-15",
    timeLogged: 480, // 8 hours in minutes
    files: 12,
    colorCode: "#3B82F6",
    icon: "web",
    userId: 1,
    aiAssistanceEnabled: true,
  },
  {
    id: 2,
    name: "Content Strategy",
    description: "Develop content strategy for Q2",
    type: "research",
    progress: 30,
    deadline: "2023-05-30",
    timeLogged: 240, // 4 hours in minutes
    files: 5,
    colorCode: "#8B5CF6",
    icon: "psychology",
    userId: 1,
    aiAssistanceEnabled: true,
  },
  {
    id: 3,
    name: "User Research",
    description: "Conduct user interviews and analyze feedback",
    type: "research",
    progress: 100,
    deadline: "2023-04-10",
    timeLogged: 360, // 6 hours in minutes
    files: 8,
    colorCode: "#10B981",
    icon: "groups",
    userId: 1,
    aiAssistanceEnabled: true,
  },
]

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [initialized, setInitialized] = useState(false)
  const storageOperationInProgress = useRef(false)

  // Load projects from localStorage only once on mount
  useEffect(() => {
    if (initialized || storageOperationInProgress.current) return

    const loadProjects = () => {
      setIsLoading(true)
      storageOperationInProgress.current = true

      try {
        const savedProjects = storage.get(STORAGE_KEY, []) as Project[]

        // If no projects exist yet, use initial sample projects
        if (savedProjects.length === 0) {
          setProjects(initialProjects)
          storage.set(STORAGE_KEY, initialProjects)
        } else {
          setProjects(savedProjects)
        }

        // Load selected project if any
        const savedSelectedProject = storage.get(SELECTED_PROJECT_KEY, null) as Project | null
        if (savedSelectedProject) {
          // Verify the project still exists
          const projectExists = savedProjects.some((p) => p.id === savedSelectedProject.id)
          if (projectExists) {
            setSelectedProject(savedSelectedProject)
          }
        }
      } catch (error) {
        console.error("Failed to load projects:", error)
      } finally {
        setIsLoading(false)
        setInitialized(true)
        storageOperationInProgress.current = false
      }
    }

    loadProjects()
  }, [initialized]) // Keep only initialized as a dependency

  // Save projects to localStorage whenever they change, but only after initialization
  useEffect(() => {
    if (!initialized || storageOperationInProgress.current) return

    // Only save if there are projects and if they've actually changed
    if (projects.length > 0) {
      storageOperationInProgress.current = true
      storage.set(STORAGE_KEY, projects)
      storageOperationInProgress.current = false
    }
  }, [projects, initialized]) // Keep only projects and initialized as dependencies

  // Save selected project whenever it changes, but only after initialization
  useEffect(() => {
    if (!initialized || storageOperationInProgress.current) return

    // Only save if selectedProject has changed
    storageOperationInProgress.current = true
    storage.set(SELECTED_PROJECT_KEY, selectedProject)
    storageOperationInProgress.current = false
  }, [selectedProject, initialized]) // Keep only selectedProject and initialized as dependencies

  const addProject = useCallback((project: Omit<Project, "id">) => {
    const newProject = {
      ...project,
      id: Date.now(),
    } as Project
    setProjects((prevProjects) => [...prevProjects, newProject])
  }, [])

  const updateProject = useCallback((id: number, updatedFields: Partial<Project>) => {
    setProjects((prevProjects) =>
      prevProjects.map((project) => (project.id === id ? { ...project, ...updatedFields } : project)),
    )

    // Update selected project if it's the one being updated
    setSelectedProject((prev) => {
      if (prev && prev.id === id) {
        return { ...prev, ...updatedFields }
      }
      return prev
    })
  }, [])

  const deleteProject = useCallback((id: number) => {
    setProjects((prevProjects) => prevProjects.filter((project) => project.id !== id))

    // Clear selected project if it's the one being deleted
    setSelectedProject((prev) => {
      if (prev && prev.id === id) {
        return null
      }
      return prev
    })
  }, [])

  const createProject = useCallback(async (project: any): Promise<Project> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    const newProject = {
      ...project,
      id: Date.now(),
      progress: 0,
      timeLogged: 0,
      files: 0,
    } as Project

    setProjects((prevProjects) => [...prevProjects, newProject])
    return newProject
  }, [])

  const getProject = useCallback(
    (id: number): Project | undefined => {
      return projects.find((project) => project.id === id)
    },
    [projects],
  )

  return (
    <ProjectContext.Provider
      value={{
        projects,
        isLoading,
        addProject,
        updateProject,
        deleteProject,
        createProject,
        getProject,
        selectedProject,
        setSelectedProject,
      }}
    >
      {children}
    </ProjectContext.Provider>
  )
}

export const useProjects = () => useContext(ProjectContext)

