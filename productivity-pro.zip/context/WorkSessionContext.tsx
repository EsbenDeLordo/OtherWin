"use client"

import { createContext, useContext, useState, useEffect, useRef, useCallback, type ReactNode } from "react"
import type { WorkSession } from "@/shared/schema"
import storage from "@/lib/storage-simple"
import { v4 as uuidv4 } from "uuid"

interface WorkSessionContextType {
  currentSession: WorkSession | null
  sessions: WorkSession[]
  startSession: (projectId: number, type: "focus" | "meeting" | "learning") => Promise<void>
  endSession: () => Promise<void>
  isSessionActive: boolean
  elapsedTime: { hours: number; minutes: number; seconds: number }
  getProjectSessions: (projectId: number) => WorkSession[]
  getTotalTimeForProject: (projectId: number) => number
}

const WorkSessionContext = createContext<WorkSessionContextType>({
  currentSession: null,
  sessions: [],
  startSession: async () => {},
  endSession: async () => {},
  isSessionActive: false,
  elapsedTime: { hours: 0, minutes: 0, seconds: 0 },
  getProjectSessions: () => [],
  getTotalTimeForProject: () => 0,
})

const SESSIONS_STORAGE_KEY = "productivity_pro_sessions"
const CURRENT_SESSION_KEY = "productivity_pro_current_session"

export function WorkSessionProvider({ children }: { children: ReactNode }) {
  const [sessions, setSessions] = useState<WorkSession[]>([])
  const [currentSession, setCurrentSession] = useState<WorkSession | null>(null)
  const [elapsedTime, setElapsedTime] = useState({ hours: 0, minutes: 0, seconds: 0 })
  const [initialized, setInitialized] = useState(false)
  const storageOperationInProgress = useRef(false)

  // Load sessions and current session from localStorage
  useEffect(() => {
    if (initialized || storageOperationInProgress.current) return

    storageOperationInProgress.current = true
    const savedSessions = storage.get(SESSIONS_STORAGE_KEY, []) as WorkSession[]
    const savedCurrentSession = storage.get(CURRENT_SESSION_KEY, null) as WorkSession | null

    setSessions(savedSessions)
    setCurrentSession(savedCurrentSession)
    setInitialized(true)
    storageOperationInProgress.current = false
  }, [initialized]) // Keep only initialized as a dependency

  // Save sessions whenever they change
  useEffect(() => {
    if (!initialized || storageOperationInProgress.current) return

    storageOperationInProgress.current = true
    storage.set(SESSIONS_STORAGE_KEY, sessions)
    storageOperationInProgress.current = false
  }, [sessions, initialized]) // Keep only sessions and initialized as dependencies

  // Save current session whenever it changes
  useEffect(() => {
    if (!initialized || storageOperationInProgress.current) return

    storageOperationInProgress.current = true
    storage.set(CURRENT_SESSION_KEY, currentSession)
    storageOperationInProgress.current = false
  }, [currentSession, initialized]) // Keep only currentSession and initialized as dependencies

  // Update elapsed time every second when a session is active
  useEffect(() => {
    if (!currentSession) return

    const interval = setInterval(() => {
      const startTime = new Date(currentSession.startTime).getTime()
      const now = new Date().getTime()
      const elapsedMs = now - startTime

      const seconds = Math.floor((elapsedMs / 1000) % 60)
      const minutes = Math.floor((elapsedMs / (1000 * 60)) % 60)
      const hours = Math.floor(elapsedMs / (1000 * 60 * 60))

      setElapsedTime({ hours, minutes, seconds })
    }, 1000)

    return () => clearInterval(interval)
  }, [currentSession])

  const startSession = useCallback(
    async (projectId: number, type: "focus" | "meeting" | "learning") => {
      // End any existing session
      if (currentSession) {
        await endSession()
      }

      // Create a new session
      const newSession: WorkSession = {
        id: uuidv4(),
        projectId,
        type,
        startTime: new Date().toISOString(),
      }

      setCurrentSession(newSession)
      return Promise.resolve()
    },
    [currentSession],
  )

  const endSession = useCallback(async () => {
    if (!currentSession) return Promise.resolve()

    const completedSession: WorkSession = {
      ...currentSession,
      endTime: new Date().toISOString(),
    }

    setSessions((prevSessions) => [...prevSessions, completedSession])
    setCurrentSession(null)
    setElapsedTime({ hours: 0, minutes: 0, seconds: 0 })

    return Promise.resolve()
  }, [currentSession])

  const getProjectSessions = useCallback(
    (projectId: number): WorkSession[] => {
      return sessions.filter((session) => session.projectId === projectId)
    },
    [sessions],
  )

  const getTotalTimeForProject = useCallback(
    (projectId: number): number => {
      const projectSessions = getProjectSessions(projectId)

      return projectSessions.reduce((total, session) => {
        if (!session.endTime) return total

        const startTime = new Date(session.startTime).getTime()
        const endTime = new Date(session.endTime).getTime()
        const sessionDuration = Math.floor((endTime - startTime) / 1000) // in seconds

        return total + sessionDuration
      }, 0)
    },
    [getProjectSessions],
  )

  return (
    <WorkSessionContext.Provider
      value={{
        currentSession,
        sessions,
        startSession,
        endSession,
        isSessionActive: !!currentSession,
        elapsedTime,
        getProjectSessions,
        getTotalTimeForProject,
      }}
    >
      {children}
    </WorkSessionContext.Provider>
  )
}

export const useWorkSession = () => useContext(WorkSessionContext)

